import { useEffect, useRef } from "react";
import * as THREE from "three";

type OrbCanvasProps = {
  size?: number;
};

export default function OrbCanvas({ size = 120 }: OrbCanvasProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let width = container.clientWidth || size;
    let height = container.clientHeight || size;

    const renderScale = 1.28;
    const sphereScale = 0.9;

    const settings = {
      speed: 0.2,
      density: 1.5,
      strength: 0.2,
      frequency: 3.0,
      amplitude: 6.0,
      intensity: 5.0,
    };

    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 4.35);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.setSize(width * renderScale, height * renderScale);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setClearColor(0x000000, 0);

    renderer.domElement.style.position = "absolute";
    renderer.domElement.style.left = "50%";
    renderer.domElement.style.top = "50%";
    renderer.domElement.style.transform = "translate(-50%, -50%)";
    renderer.domElement.style.display = "block";

    container.appendChild(renderer.domElement);

    const clock = new THREE.Clock();

    const mouse = new THREE.Vector2(0, 0);
    const mouseTarget = new THREE.Vector2(0, 0);
    let hover = 0;
    let hoverTarget = 0;
    let idleRotationY = 0;

    const noise = `
      vec3 mod289(vec3 x)
      {
        return x - floor(x * (1.0 / 289.0)) * 289.0;
      }

      vec4 mod289(vec4 x)
      {
        return x - floor(x * (1.0 / 289.0)) * 289.0;
      }

      vec4 permute(vec4 x)
      {
        return mod289(((x*34.0)+1.0)*x);
      }

      vec4 taylorInvSqrt(vec4 r)
      {
        return 1.79284291400159 - 0.85373472095314 * r;
      }

      vec3 fade(vec3 t) {
        return t*t*t*(t*(t*6.0-15.0)+10.0);
      }

      float pnoise(vec3 P, vec3 rep)
      {
        vec3 Pi0 = mod(floor(P), rep);
        vec3 Pi1 = mod(Pi0 + vec3(1.0), rep);
        Pi0 = mod289(Pi0);
        Pi1 = mod289(Pi1);
        vec3 Pf0 = fract(P);
        vec3 Pf1 = Pf0 - vec3(1.0);
        vec4 ix = vec4(Pi0.x, Pi1.x, Pi0.x, Pi1.x);
        vec4 iy = vec4(Pi0.yy, Pi1.yy);
        vec4 iz0 = Pi0.zzzz;
        vec4 iz1 = Pi1.zzzz;

        vec4 ixy = permute(permute(ix) + iy);
        vec4 ixy0 = permute(ixy + iz0);
        vec4 ixy1 = permute(ixy + iz1);

        vec4 gx0 = ixy0 * (1.0 / 7.0);
        vec4 gy0 = fract(floor(gx0) * (1.0 / 7.0)) - 0.5;
        gx0 = fract(gx0);
        vec4 gz0 = vec4(0.5) - abs(gx0) - abs(gy0);
        vec4 sz0 = step(gz0, vec4(0.0));
        gx0 -= sz0 * (step(0.0, gx0) - 0.5);
        gy0 -= sz0 * (step(0.0, gy0) - 0.5);

        vec4 gx1 = ixy1 * (1.0 / 7.0);
        vec4 gy1 = fract(floor(gx1) * (1.0 / 7.0)) - 0.5;
        gx1 = fract(gx1);
        vec4 gz1 = vec4(0.5) - abs(gx1) - abs(gy1);
        vec4 sz1 = step(gz1, vec4(0.0));
        gx1 -= sz1 * (step(0.0, gx1) - 0.5);
        gy1 -= sz1 * (step(0.0, gy1) - 0.5);

        vec3 g000 = vec3(gx0.x,gy0.x,gz0.x);
        vec3 g100 = vec3(gx0.y,gy0.y,gz0.y);
        vec3 g010 = vec3(gx0.z,gy0.z,gz0.z);
        vec3 g110 = vec3(gx0.w,gy0.w,gz0.w);
        vec3 g001 = vec3(gx1.x,gy1.x,gz1.x);
        vec3 g101 = vec3(gx1.y,gy1.y,gz1.y);
        vec3 g011 = vec3(gx1.z,gy1.z,gz1.z);
        vec3 g111 = vec3(gx1.w,gy1.w,gz1.w);

        vec4 norm0 = taylorInvSqrt(vec4(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
        g000 *= norm0.x;
        g010 *= norm0.y;
        g100 *= norm0.z;
        g110 *= norm0.w;

        vec4 norm1 = taylorInvSqrt(vec4(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
        g001 *= norm1.x;
        g011 *= norm1.y;
        g101 *= norm1.z;
        g111 *= norm1.w;

        float n000 = dot(g000, Pf0);
        float n100 = dot(g100, vec3(Pf1.x, Pf0.yz));
        float n010 = dot(g010, vec3(Pf0.x, Pf1.y, Pf0.z));
        float n110 = dot(g110, vec3(Pf1.xy, Pf0.z));
        float n001 = dot(g001, vec3(Pf0.xy, Pf1.z));
        float n101 = dot(g101, vec3(Pf1.x, Pf0.y, Pf1.z));
        float n011 = dot(g011, vec3(Pf0.x, Pf1.yz));
        float n111 = dot(g111, Pf1);

        vec3 fade_xyz = fade(Pf0);
        vec4 n_z = mix(vec4(n000, n100, n010, n110), vec4(n001, n101, n011, n111), fade_xyz.z);
        vec2 n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
        float n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x);
        return 2.2 * n_xyz;
      }
    `;

    const rotation = `
      mat3 rotation3dY(float angle) {
        float s = sin(angle);
        float c = cos(angle);

        return mat3(
          c, 0.0, -s,
          0.0, 1.0, 0.0,
          s, 0.0, c
        );
      }

      vec3 rotateY(vec3 v, float angle) {
        return rotation3dY(angle) * v;
      }
    `;

    const vertexShader = `
      varying vec2 vUv;
      varying float vDistort;
      varying float vHoverMask;

      uniform float uTime;
      uniform float uSpeed;
      uniform float uNoiseDensity;
      uniform float uNoiseStrength;
      uniform float uFrequency;
      uniform float uAmplitude;
      uniform vec2 uMouse;
      uniform float uHover;

      ${noise}
      ${rotation}

      void main() {
        vUv = uv;

        float t = uTime * uSpeed;
        float distortion = pnoise((normal + t) * uNoiseDensity, vec3(10.0)) * uNoiseStrength;

        vec3 pos = position + (normal * distortion);
        float angle = sin(uv.y * uFrequency + t) * uAmplitude;
        pos = rotateY(pos, angle);

        float md = distance(normal.xy, uMouse * 0.75);
        float hoverMask = smoothstep(0.95, 0.05, md) * uHover;
        pos += normal * hoverMask * 0.08;

        vHoverMask = hoverMask;
        vDistort = distortion + hoverMask * 0.06;

        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `;

    const fragmentShader = `
      varying vec2 vUv;
      varying float vDistort;
      varying float vHoverMask;

      uniform float uIntensity;
      uniform float uHover;

      vec3 cosPalette(float t, vec3 a, vec3 b, vec3 c, vec3 d) {
        return a + b * cos(6.28318 * (c * t + d));
      }

      void main() {
        float distort = vDistort * uIntensity;

        vec3 brightness = vec3(0.5, 0.5, 0.5);
        vec3 contrast = vec3(0.5, 0.5, 0.5);
        vec3 oscillation = vec3(1.0, 1.0, 1.0);
        vec3 phase = vec3(0.0, 0.1, 0.2);

        vec3 color = cosPalette(distort, brightness, contrast, oscillation, phase);

        color += vec3(0.08, 0.14, 0.24) * vHoverMask * 0.8;
        color += vec3(0.03, 0.06, 0.10) * uHover * 0.15;

        gl_FragColor = vec4(color, 1.0);
      }
    `;

    const geometry = new THREE.IcosahedronGeometry(1 * sphereScale, 64);
    const material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uSpeed: { value: settings.speed },
        uNoiseDensity: { value: settings.density },
        uNoiseStrength: { value: settings.strength },
        uFrequency: { value: settings.frequency },
        uAmplitude: { value: settings.amplitude },
        uIntensity: { value: settings.intensity },
        uMouse: { value: new THREE.Vector2(0, 0) },
        uHover: { value: 0 },
      },
    });

    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const handleResize = () => {
      width = container.clientWidth || size;
      height = container.clientHeight || size;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
      renderer.setSize(width * renderScale, height * renderScale);
    };

    const handlePointerMove = (event: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);

      mouseTarget.set(x, y);
      hoverTarget = 1;
    };

    const handlePointerLeave = () => {
      mouseTarget.set(0, 0);
      hoverTarget = 0;
    };

    renderer.domElement.addEventListener("pointermove", handlePointerMove);
    renderer.domElement.addEventListener("pointerleave", handlePointerLeave);
    window.addEventListener("resize", handleResize);

    let rafRef = 0;

    const animate = () => {
      const elapsed = clock.getElapsedTime();

      mouse.lerp(mouseTarget, 0.045);
      hover += (hoverTarget - hover) * 0.04;

      material.uniforms.uTime.value = elapsed;
      material.uniforms.uMouse.value.copy(mouse);
      material.uniforms.uHover.value = hover;

      idleRotationY += 0.0032;
      mesh.rotation.y += ((idleRotationY + mouse.x * 0.22) - mesh.rotation.y) * 0.05;
      mesh.rotation.x += ((mouse.y * 0.18) - mesh.rotation.x) * 0.05;
      mesh.position.x += ((mouse.x * 0.08) - mesh.position.x) * 0.04;
      mesh.position.y += ((mouse.y * 0.08) - mesh.position.y) * 0.04;

      renderer.render(scene, camera);
      rafRef = requestAnimationFrame(animate);
    };

    rafRef = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafRef);
      window.removeEventListener("resize", handleResize);
      renderer.domElement.removeEventListener("pointermove", handlePointerMove);
      renderer.domElement.removeEventListener("pointerleave", handlePointerLeave);

      geometry.dispose();
      material.dispose();
      renderer.dispose();

      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [size]);

  return (
    <div
      ref={mountRef}
      className="orb-wrapper"
      style={{
        width: size,
        height: size,
        position: "relative",
        display: "block",
        overflow: "visible",
        borderRadius: "9999px",
      }}
    />
  );
}